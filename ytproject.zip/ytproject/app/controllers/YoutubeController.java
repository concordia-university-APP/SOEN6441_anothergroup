package controllers;

import com.google.api.services.youtube.model.SearchResult;
import play.mvc.Controller;
import play.mvc.Result;
import services.YoutubeService;
import views.html.search;
import scala.jdk.javaapi.OptionConverters;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class YoutubeController extends Controller {

    public Result search(String query) {
        try {
            List<SearchResult> results = YoutubeService.searchVideosWithKeywords(query);
            scala.Option<List<SearchResult>> scalaResults = OptionConverters.toScala(Optional.of(results));
            return ok(search.render(scalaResults));
        } catch (IOException e) {
            return internalServerError("Error occurred while searching YouTube");
        }
    }

}
