package controllers;

import com.google.api.services.youtube.model.SearchResult;
import play.mvc.Controller;
import play.mvc.Result;
import services.YoutubeService;
import views.html.search;
import scala.jdk.javaapi.OptionConverters;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import scala.Option;

public class YoutubeController extends Controller {

    public Result search(String query) {
        try {
            List<SearchResult> results = YoutubeService.searchVideosWithKeywords(query);
            Option<List<SearchResult>> scalaResults;
            if (results.isEmpty()) {
                scalaResults = scala.Option.empty();
            } else {
                scalaResults = OptionConverters.toScala(Optional.of(results));
            }
            return ok(views.html.search.render(scalaResults));
        } catch (IOException e) {
            return internalServerError("Error occurred while searching YouTube: " + e.getMessage());
        }
    }
    public Result searchForm() {
        java.util.Optional<List<SearchResult>> results = java.util.Optional.empty();
        return ok(views.html.search.render(OptionConverters.toScala(results)));
    }

}
