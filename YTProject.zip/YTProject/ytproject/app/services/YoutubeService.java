package services;


import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class YoutubeService {
    public static List<SearchResult> searchVideosWithKeywords(String keywords) throws IOException {
        YouTube youtube = new YouTube.Builder(new NetHttpTransport(), new GsonFactory(), new HttpRequestInitializer() {
            public void initialize(HttpRequest request) throws IOException {
            }
        }).setApplicationName("another-group").build();

        YouTube.Search.List search = youtube.search().list("id,snippet");
        search.setType("video");
        search.setKey("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");
        search.setOrder("date");
        search.setQ(keywords);
        search.setFields("items(id/kind,id/videoId,snippet/title,snippet/thumbnails/default/url)");
        search.setMaxResults(10L);
        try {
            SearchListResponse searchResponse = search.execute();
            List<SearchResult> items = searchResponse.getItems();
            return items != null ? items : Collections.emptyList();
        } catch (IOException e) {
            throw new IOException("Error occurred while executing YouTube search: " + e.getMessage(), e);
        }
    }


}
